# -*- coding: utf-8 -*-
# @Time    : 2022/6/18 11:36
# @Author  : AI悦创
# @FileName: TuringRobots_Tests.py
# @Software: PyCharm
# @Blog    ：https://bornforthis.cn/
from TuringRobots import TuringRobots

def test_TuringRobots():
	assert TuringRobots.TuringRobots("我是天才，那你呢？", over_print=True)
